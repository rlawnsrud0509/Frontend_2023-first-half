export { default as Header } from "./common/header/index";
export { default as Main } from "./menu/index";
export { default as Post } from "./post/index";
