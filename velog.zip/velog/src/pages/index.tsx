export { default as MainPage } from "./main/index";
export { default as WritingPage } from "./write/index";