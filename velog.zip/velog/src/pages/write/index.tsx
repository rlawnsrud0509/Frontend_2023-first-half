import * as C from "../../components/index";

export default function WritingPage() {
  return (
    <>
      <C.Header />
    </>
  );
}
